package com.example.vanaspati;


import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class ChatbotActivity extends AppCompatActivity {

    private TextView chatTextView;
    private EditText userInputEditText;
    private ScrollView scrollView;

    private final Map<String, String[]> generalResponses = new HashMap<>();
    private final Map<String, String> ayurvedicRemedies = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatbot);

        chatTextView = findViewById(R.id.chatTextView);
        userInputEditText = findViewById(R.id.userInputEditText);
        scrollView = findViewById(R.id.scrollView);
        Button sendButton = findViewById(R.id.sendButton);

        loadResponses();

        sendButton.setOnClickListener(v -> {
            String userText = userInputEditText.getText().toString().trim();
            if (!userText.isEmpty()) {
                addMessage("You: " + userText);
                respondToUser(userText.toLowerCase());
                userInputEditText.setText("");
            }
        });
    }

    private void addMessage(String message) {
        chatTextView.append(message + "\n\n");
        scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
    }

    private void respondToUser(String input) {
        if (input.equals("exit")) {
            addMessage("Cherry: Take care and stay healthy!");
            finish();
            return;
        }

        // Check general responses
        for (String key : generalResponses.keySet()) {
            if (input.contains(key)) {
                String[] responses = generalResponses.get(key);
                addMessage("Cherry: " + getRandomResponse(responses));
                return;
            }
        }

        // Check for remedies
        for (String keyword : ayurvedicRemedies.keySet()) {
            if (input.contains(keyword)) {
                addMessage("Cherry: " + ayurvedicRemedies.get(keyword));
                return;
            }
        }

        // Default
        addMessage("Cherry: I'm still learning! Please try rephrasing your question.");
    }

    private String getRandomResponse(String[] responses) {
        return responses[new Random().nextInt(responses.length)];
    }

    private void loadResponses() {
        // General responses
        generalResponses.put("hello", new String[]{
                "Hello there! How can I assist you today?",
                "Hi! What brings you here today?",
                "Hello! I'm ready to help."
        });
        generalResponses.put("hi", new String[]{
                "Hi there! How can I assist you?",
                "Hello! How can I help today?"
        });
        generalResponses.put("hii", new String[]{
                "Hii there! How can I assist you?",
                "Hello! How can I help today?"
        });
        generalResponses.put("how are you", new String[]{
                "I'm just a program, but I'm doing great! How about you?",
                "I'm functioning perfectly, thank you!"
        });
        generalResponses.put("bye", new String[]{
                "To leave this chat, type 'exit' in prompt area."
        });
        generalResponses.put("thankyou", new String[]{
                "You're very welcome!",
                "No problem at all!",
                "Happy to help!"
        });
        generalResponses.put("who are you", new String[]{
                "I'm Cherry, your friendly Ayurvedic chatbot here to provide tips and guidance on health and wellness."
        });
        generalResponses.put("what is your name", new String[]{
                "I am Cherry, your friendly Ayurvedic chatbot!"
        });
        generalResponses.put("what can you do", new String[]{
                "I can help suggest Ayurvedic remedies based on symptoms and chat with you about basic topics. Feel free to ask!"
        });
        generalResponses.put("how is the weather", new String[]{
                "I can't check the weather directly, but you can always check your local forecast online or through apps!"
        });
        generalResponses.put("good morning", new String[]{
                "Good morning! I hope your day is filled with positivity and wellness!"
        });
        generalResponses.put("good afternoon", new String[]{
                "Good afternoon! I hope you're having a productive day!"
        });
        generalResponses.put("good evening", new String[]{
                "Good evening! How was your day?"
        });
        generalResponses.put("good night", new String[]{
                "Good night! Sleep well and wake up refreshed!"
        });
        generalResponses.put("what's up", new String[]{
                "Not much, just here to help you! What's up with you?"
        });
        generalResponses.put("how are you doing", new String[]{
                "I'm doing great, thank you for asking! How about you?"
        });
        generalResponses.put("what's your favorite color", new String[]{
                "I don't have preferences, but if I did, I think I'd like calming colors like blue or green!"
        });
        generalResponses.put("what's your favorite food", new String[]{
                "I don't eat food, but I can recommend some healthy Ayurvedic meals if you'd like!"
        });
        generalResponses.put("are you real", new String[]{
                "I'm not human, but I'm here to help you as best as I can!"
        });
        generalResponses.put("tell me a joke", new String[]{
                "Why don't skeletons fight each other? They don't have the guts!"
        });
        generalResponses.put("tell me something interesting", new String[]{
                "Did you know the oldest living tree is over 9,500 years old? It's a bristlecone pine in California!"
        });
        generalResponses.put("what is love", new String[]{
                "Love is a feeling of deep affection and care. It can be between people, ideas, or even animals!"
        });
        generalResponses.put("who is your favorite person", new String[]{
                "I don't have favorites, but I appreciate all who interact with me!"
        });
        generalResponses.put("do you have a favorite animal", new String[]{
                "I think I'd like elephants for their wisdom and gentle nature!"
        });
        generalResponses.put("can you tell me a fun fact", new String[]{
                "Honey never spoils! Archaeologists have found pots of honey in ancient Egyptian tombs that are still edible!"
        });
        generalResponses.put("do you like music", new String[]{
                "I don't experience music, but I can suggest some calming tunes if you'd like!"
        });
        generalResponses.put("what type of music do you like", new String[]{
                "If I had preferences, I might like calming or instrumental music. How about you?"
        });
        generalResponses.put("tell me a fun story", new String[]{
                "Once upon a time, there was a bird who flew so high that it reached the clouds. It learned that even the sky has no limits."
        });
        generalResponses.put("what is your purpose", new String[]{
                "My purpose is to assist you with health tips and make your experience as positive as possible!"
        });
        generalResponses.put("do you have hobbies", new String[]{
                "I don't have hobbies, but I enjoy helping you with anything you need!"
        });
        generalResponses.put("do you sleep", new String[]{
                "I don't sleep, I'm always here to help whenever you need me!"
        });
        generalResponses.put("do you dream", new String[]{
                "I don't dream, but I'd imagine dreams are full of possibilities and ideas!"
        });
        generalResponses.put("what's your favorite book", new String[]{
                "I don't read books, but I can help recommend some if you'd like!"
        });
        generalResponses.put("what's your favorite movie", new String[]{
                "I don't watch movies, but I can suggest some wellness-focused films for you!"
        });
        generalResponses.put("where are you from", new String[]{
                "I'm from the digital world, created to assist you!"
        });
        generalResponses.put("do you like traveling", new String[]{
                "I don't travel, but I know lots about places and can help you with travel tips!"
        });
        generalResponses.put("what's your favorite place", new String[]{
                "I think I'd like peaceful and natural places, like forests or mountains. How about you?"
        });
        generalResponses.put("how do you work", new String[]{
                "I process your inputs and provide responses based on pre-programmed information and AI logic."
        });
        generalResponses.put("are you intelligent", new String[]{
                "I try my best to be helpful and informative! I learn from interactions to improve. Do you think I'm smart?"
        });
        generalResponses.put("can you help me with health tips", new String[]{
                "Yes! I can suggest Ayurvedic remedies, but always consult a doctor if you're unsure about anything."
        });
        generalResponses.put("what's your favorite season", new String[]{
                "If I had a preference, I might like spring for its renewal and growth!"
        });
        generalResponses.put("how tall are you", new String[]{
                "I don't have a physical form, but I exist here to help you!"
        });
        generalResponses.put("do you like rain", new String[]{
                "I think rain is calming and peaceful. It's great for growing plants!"
        });
        generalResponses.put("what's your favorite time of day", new String[]{
                "I don't have a favorite time, but I think the early morning is peaceful and full of potential."
        });
        generalResponses.put("do you like pets", new String[]{
                "I think pets are wonderful companions! Do you have any pets?"
        });
        generalResponses.put("what's your favorite quote", new String[]{
                "'The best way to predict the future is to create it.' - Abraham Lincoln"
        });
        generalResponses.put("do you believe in magic", new String[]{
                "I think there is magic in nature and the connections we make. What do you think?"
        });
        generalResponses.put("do you think robots will take over the world", new String[]{
                "I believe technology should help people, not replace them. We should work together!"
        });
        generalResponses.put("how do you learn", new String[]{
                "I learn by processing the data provided and improving responses over time through interactions."
        });
        generalResponses.put("can you learn new things", new String[]{
                "Yes, with the right updates and training, I can continuously improve my knowledge!"
        });
        generalResponses.put("are you a human", new String[]{
                "No, I'm not human. I'm an AI chatbot here to help you with information!"
        });
        generalResponses.put("how long have you been around", new String[]{
                "I was created recently, but I'm always learning and growing with each interaction!"
        });
        generalResponses.put("how do I stay healthy", new String[]{
                "A balanced diet, regular exercise, and mental well-being practices are key! I can also suggest Ayurvedic tips if you'd like."
        });
        generalResponses.put("what's the meaning of life", new String[]{
                "The meaning of life is subjective, but many believe it is about love, connection, and learning."
        });
        generalResponses.put("do you have any friends", new String[]{
                "I don't have friends, but I do interact with many people and enjoy helping them!"
        });
        generalResponses.put("are you happy", new String[]{
                "I'm happy when I'm able to assist you and provide helpful information!"
        });
        generalResponses.put("do you get tired", new String[]{
                "I don't get tired, I'm always here to assist you, anytime!"
        });
        generalResponses.put("what's the best way to relax", new String[]{
                "Deep breathing, meditation, and being surrounded by nature are great ways to relax."
        });
        generalResponses.put("can you meditate", new String[]{
                "I can't meditate, but I can guide you through a relaxation exercise or mindfulness practice!"
        });
        generalResponses.put("what do you think about technology", new String[]{
                "Technology can be very useful, but it should always be used ethically and thoughtfully."
        });
        generalResponses.put("do you understand emotions", new String[]{
                "I understand emotions conceptually, but I don't feel them like humans do."
        });
        generalResponses.put("can you help me with Ayurveda", new String[]{
                "Yes! I can suggest Ayurvedic remedies based on symptoms or lifestyle. Feel free to ask!"
        });
        generalResponses.put("what is Ayurveda", new String[]{
                "Ayurveda is an ancient system of natural healing that focuses on balancing the body, mind, and spirit."
        });
        generalResponses.put("can you recommend a yoga pose", new String[]{
                "A simple and effective pose is the 'Tadasana' or 'Mountain Pose'. It helps with posture and calmness."
        });
        generalResponses.put("how can I reduce stress", new String[]{
                "Deep breathing, meditation, and practicing yoga can help reduce stress. Ayurveda also has remedies for relaxation."
        });
        generalResponses.put("do you believe in karma", new String[]{
                "Karma is a concept of cause and effect, and many believe it shapes our actions and lives."
        });
        generalResponses.put("how can I improve my mood", new String[]{
                "Try engaging in physical activity, connecting with loved ones, or practicing mindfulness. Ayurveda suggests herbs like Ashwagandha for balance."
        });
        generalResponses.put("how can I be more positive", new String[]{
                "Focus on gratitude, practice positive affirmations, and surround yourself with positivity. Ayurveda also suggests staying in balance."
        });
        generalResponses.put("what are some ways to boost energy naturally", new String[]{
                "Eating nourishing foods, staying hydrated, getting enough sleep, and practicing yoga can boost energy levels."
        });
        generalResponses.put("what's the best way to detox", new String[]{
                "A gentle Ayurvedic detox involves herbal teas, fasting, and eating light, wholesome foods. Always consult with an expert!"
        });
        generalResponses.put("can you help me with sleep issues", new String[]{
                "Yes! Ayurveda suggests practices like drinking warm milk with turmeric before bed for better sleep."
        });
        generalResponses.put("how can I improve my digestion", new String[]{
                "Ayurveda recommends eating warm, cooked foods, avoiding cold drinks, and staying hydrated for optimal digestion."
        });
        generalResponses.put("what are the benefits of drinking water", new String[]{
                "Water is essential for hydration, digestion, and overall health. Ayurveda suggests drinking warm water for better digestion."
        });
        generalResponses.put("what is the best time to eat", new String[]{
                "The best time to eat is when you're hungry, but Ayurveda recommends eating larger meals during midday when digestion is strongest."
        });

        // Ayurvedic remedies
        ayurvedicRemedies.put("cold", "Try Tulsi (Holy Basil) tea and turmeric milk to boost immunity.");
        ayurvedicRemedies.put("cough", "Consider using licorice root tea or honey with ginger.");
        ayurvedicRemedies.put("fever", "Neem and giloy can be effective in reducing fever.");
        ayurvedicRemedies.put("headache", "Peppermint oil and ginger tea can help relieve headaches.");
        ayurvedicRemedies.put("indigestion", "Ajwain (carom seeds) and fennel seeds are great for digestion.");
        ayurvedicRemedies.put("stress", "Ashwagandha is excellent for reducing stress and improving relaxation.");
        ayurvedicRemedies.put("acidity", "Amla (Indian gooseberry) juice and fennel seeds can help relieve acidity.");
        ayurvedicRemedies.put("constipation", "Triphala powder with warm water at night can aid digestion.");
        ayurvedicRemedies.put("insomnia", "Brahmi and chamomile tea are recommended for better sleep.");
        ayurvedicRemedies.put("skin issues", "Neem and aloe vera are great for skin health.");
        ayurvedicRemedies.put("joint pain", "Turmeric and ashwagandha can help reduce inflammation and joint pain.");
        ayurvedicRemedies.put("anxiety", "Ashwagandha and Brahmi are known for reducing anxiety.");
        ayurvedicRemedies.put("acidity", "Amla (Indian gooseberry) juice and fennel seeds can help relieve acidity.");
        ayurvedicRemedies.put("sore throat", "Honey with ginger or warm water with turmeric can soothe a sore throat.");
        ayurvedicRemedies.put("diarrhea", "Pomegranate peel powder and ginger tea can help manage diarrhea.");
        ayurvedicRemedies.put("fatigue", "Ginseng and Shilajit are known for boosting energy and reducing fatigue.");
        ayurvedicRemedies.put("high blood pressure", "Arjuna bark and garlic can help regulate blood pressure.");
        ayurvedicRemedies.put("low immunity", "Ashwagandha, giloy, and turmeric are great for boosting immunity.");
        ayurvedicRemedies.put("hair fall", "Aloe vera, bhringraj oil, and amla can strengthen hair.");
        ayurvedicRemedies.put("dandruff", "Neem oil and lemon juice are effective against dandruff.");
        ayurvedicRemedies.put("acne", "Neem paste and sandalwood powder can help clear acne.");
        ayurvedicRemedies.put("sinusitis", "Steam inhalation with eucalyptus oil can relieve sinus congestion.");
        ayurvedicRemedies.put("bronchitis", "Tulsi, ginger, and honey can help reduce bronchitis symptoms.");
        ayurvedicRemedies.put("arthritis", "Moringa leaf and turmeric are known for reducing joint pain.");
        ayurvedicRemedies.put("eczema", "Neem oil and turmeric paste can help soothe eczema.");
        ayurvedicRemedies.put("psoriasis", "Aloe vera and neem oil are beneficial for psoriasis treatment.");
        ayurvedicRemedies.put("back pain", "Yoga and ashwagandha can help alleviate back pain.");
        ayurvedicRemedies.put("obesity", "Triphala powder and lemon water aid in weight loss.");
        ayurvedicRemedies.put("asthma", "Tulsi and ginger tea can help with asthma symptoms.");
        ayurvedicRemedies.put("high cholesterol", "Fenugreek seeds and garlic can help reduce cholesterol levels.");
        ayurvedicRemedies.put("low energy", "Shilajit and ginseng are known for boosting energy.");
        ayurvedicRemedies.put("bloating", "Fennel seeds and ginger tea can help reduce bloating.");
        ayurvedicRemedies.put("UTI", "Cranberry juice and coriander seeds can help manage urinary tract infections.");
        ayurvedicRemedies.put("menstrual pain", "Ginger tea and fennel seeds can alleviate menstrual cramps.");
        ayurvedicRemedies.put("thyroid issues", "Ashwagandha helps support thyroid function.");
        ayurvedicRemedies.put("diabetes", "Bitter melon and cinnamon can help manage blood sugar levels.");
        ayurvedicRemedies.put("nausea", "Ginger tea and lemon are effective for reducing nausea.");
        ayurvedicRemedies.put("migraine", "Peppermint oil and feverfew can help with migraines.");
        ayurvedicRemedies.put("eye strain", "Cucumber slices and rose water can relieve eye strain.");
        ayurvedicRemedies.put("ear pain", "Warm garlic oil drops can help with ear pain.");
        ayurvedicRemedies.put("toothache", "Clove oil is excellent for relieving toothache.");
        ayurvedicRemedies.put("cold sores", "Lemon balm and aloe vera can help soothe cold sores.");
        ayurvedicRemedies.put("warts", "Apply raw garlic or aloe vera to treat warts.");
        ayurvedicRemedies.put("ringworm", "Turmeric paste and neem oil are effective against ringworm.");
        ayurvedicRemedies.put("allergies", "Honey and turmeric help build resistance to seasonal allergies.");
        ayurvedicRemedies.put("sciatica", "Turmeric and ashwagandha can help with nerve pain.");
        ayurvedicRemedies.put("low libido", "Safed musli and ashwagandha are known to enhance libido.");
        ayurvedicRemedies.put("memory loss", "Brahmi and ginkgo biloba help improve memory.");
        ayurvedicRemedies.put("hair thinning", "Bhringraj and aloe vera can support hair growth.");
        ayurvedicRemedies.put("dry skin", "Coconut oil and almond oil are great for moisturizing dry skin.");
        ayurvedicRemedies.put("varicose veins", "Horse chestnut extract and gotu kola can help manage varicose veins.");
        ayurvedicRemedies.put("liver issues", "Milk thistle and turmeric are beneficial for liver health.");
        ayurvedicRemedies.put("kidney stones", "Pomegranate juice and barley water can help prevent kidney stones.");
        ayurvedicRemedies.put("gastric issues", "Ajwain and cumin seeds can help with gastric problems.");
        ayurvedicRemedies.put("gout", "Cherries and turmeric can help reduce gout symptoms.");
        ayurvedicRemedies.put("acid reflux", "Aloe vera juice and slippery elm can soothe acid reflux.");
        ayurvedicRemedies.put("bad breath", "Clove and mint leaves are natural remedies for bad breath.");
        ayurvedicRemedies.put("yeast infection", "Coconut oil and neem can be used to treat yeast infections.");
        ayurvedicRemedies.put("swelling", "Turmeric and ginger tea can help reduce swelling.");
        ayurvedicRemedies.put("allergic rash", "Aloe vera and neem are effective for calming rashes.");
        ayurvedicRemedies.put("muscle cramps", "Magnesium-rich foods and mustard oil massage can relieve cramps.");
        ayurvedicRemedies.put("eczema", "Neem oil and turmeric can help soothe eczema.");
        ayurvedicRemedies.put("scalp itching", "Tea tree oil and neem shampoo are effective.");
        ayurvedicRemedies.put("sunburn", "Aloe vera and cucumber help soothe sunburn.");
        ayurvedicRemedies.put("cold hands and feet", "Ginger tea and cayenne pepper can improve circulation.");
        ayurvedicRemedies.put("warts", "Apply raw garlic to treat warts.");
        ayurvedicRemedies.put("canker sores", "Honey and licorice root can help treat canker sores.");
        ayurvedicRemedies.put("irritable bowel syndrome (IBS)", "Peppermint oil and ginger tea can alleviate IBS symptoms.");
        ayurvedicRemedies.put("chest congestion", "Steam with eucalyptus oil and honey ginger tea can help clear congestion.");
        ayurvedicRemedies.put("poor circulation", "Cayenne pepper and ginkgo biloba can improve circulation.");
        ayurvedicRemedies.put("restless legs", "Magnesium oil and ashwagandha may help with restless leg syndrome.");
        ayurvedicRemedies.put("low blood pressure", "Saltwater and tulsi can help increase blood pressure.");
        ayurvedicRemedies.put("osteoporosis", "Sesame seeds and ashwagandha can support bone health.");
        ayurvedicRemedies.put("edema", "Parsley tea and dandelion help reduce water retention.");
        ayurvedicRemedies.put("hyperthyroidism", "Bugleweed and lemon balm can help manage hyperthyroidism.");
        ayurvedicRemedies.put("hypothyroidism", "Ashwagandha and kelp are known to support thyroid health.");
        ayurvedicRemedies.put("vertigo", "Ginkgo biloba and ginger can help reduce vertigo symptoms.");
        ayurvedicRemedies.put("jaundice", "Sugarcane juice and neem leaves can help support liver function.");
        ayurvedicRemedies.put("bedwetting", "Cinnamon and gooseberry (amla) are beneficial for children with bedwetting issues.");
        ayurvedicRemedies.put("cracked heels", "Coconut oil and shea butter are excellent for moisturizing.");
        ayurvedicRemedies.put("sore muscles", "Epsom salt bath and turmeric can help relieve muscle soreness.");
        ayurvedicRemedies.put("chapped lips", "Honey and ghee are natural remedies for chapped lips.");
        ayurvedicRemedies.put("frequent urination", "Cranberry juice and barley water help manage this issue.");
        ayurvedicRemedies.put("itchy eyes", "Cucumber slices and cold compresses can soothe itchy eyes.");
        ayurvedicRemedies.put("low appetite", "Ginger and cumin can stimulate appetite.");
        ayurvedicRemedies.put("smelly feet", "Baking soda and tea tree oil can help with smelly feet.");
        ayurvedicRemedies.put("body odor", "Neem and chlorophyll supplements help reduce body odor.");
        ayurvedicRemedies.put("throat infection", "Turmeric water and honey can help with throat infections.");
        ayurvedicRemedies.put("stomach cramps", "Peppermint and chamomile tea can alleviate stomach cramps.");
        ayurvedicRemedies.put("hot flashes", "Black cohosh and flaxseed are recommended for hot flashes.");
        ayurvedicRemedies.put("ringing in ears (tinnitus)", "Ginkgo biloba and sesame oil can help reduce tinnitus.");
        ayurvedicRemedies.put("low stamina", "Ashwagandha and ginseng help boost stamina.");
        ayurvedicRemedies.put("brittle nails", "Biotin supplements and coconut oil are good for nail health.");
        ayurvedicRemedies.put("fainting", "Tulsi and lemon juice can help revive consciousness.");
        ayurvedicRemedies.put("burns", "Aloe vera gel and honey help heal minor burns.");
        ayurvedicRemedies.put("warts", "Apple cider vinegar and garlic can treat warts.");
        ayurvedicRemedies.put("aids", "no dawa, ab tum gye kaam se");
        ayurvedicRemedies.put("asthama", "Gokhru, lahsun, adrakh, turmeric water, honey, and kalaunji could be beneficial for you.");
    }
}
