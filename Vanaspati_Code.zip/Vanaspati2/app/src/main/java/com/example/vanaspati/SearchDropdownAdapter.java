package com.example.vanaspati;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;

import java.util.List;

public class SearchDropdownAdapter extends ArrayAdapter<Plant> {

    private Context context;
    private List<Plant> plantList;

    public SearchDropdownAdapter(@NonNull Context context, List<Plant> plants) {
        super(context, 0, plants);
        this.context = context;
        this.plantList = plants;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.plant_dropdown_item, parent, false);
        }

        Plant plant = plantList.get(position);

        TextView name = convertView.findViewById(R.id.plant_name);
        ImageView image = convertView.findViewById(R.id.plant_image);

        name.setText(plant.getCommonName());
        Glide.with(context).load(plant.getImageUrl()).into(image);

        return convertView;
    }
}
