package com.example.vanaspati;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ApologyPageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apology_page);

        // Get the message from the Intent
        String apologyMessage = getIntent().getStringExtra("apology_message");

        // Bind the TextView and Button
        TextView apologyTextView = findViewById(R.id.apology_text);
        Button backButton = findViewById(R.id.back_button);

        // Set the apology message to the TextView
        if (apologyMessage != null) {
            apologyTextView.setText(apologyMessage);
        }

        // Set up the Back Button to finish the activity and return to the previous screen
        backButton.setOnClickListener(v -> finish());
    }
}
