package com.example.vanaspati;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class PlantAdapter extends RecyclerView.Adapter<PlantAdapter.PlantViewHolder> {

    public interface OnBookmarkRemovedListener {
        void onBookmarkRemoved();
    }

    private List<Plant> plantList;
    private Context context;
    private boolean showBookmarkIcon;
    private OnBookmarkRemovedListener bookmarkRemovedListener;

    public PlantAdapter(Context context, List<Plant> plantList, boolean showBookmarkIcon) {
        this.context = context;
        this.plantList = plantList;
        this.showBookmarkIcon = showBookmarkIcon;
    }

    public PlantAdapter(Context context, List<Plant> plantList) {
        this(context, plantList, false);
    }

    public void setOnBookmarkRemovedListener(OnBookmarkRemovedListener listener) {
        this.bookmarkRemovedListener = listener;
    }

    public void updateList(List<Plant> newList) {
        plantList.clear();
        plantList.addAll(newList);
        notifyDataSetChanged();
    }

    public void removePlant(int position) {
        if (position >= 0 && position < plantList.size()) {
            plantList.remove(position);
            notifyItemRemoved(position);
            if (plantList.isEmpty() && bookmarkRemovedListener != null) {
                bookmarkRemovedListener.onBookmarkRemoved();
            }
        }
    }

    @NonNull
    @Override
    public PlantViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_plant, parent, false);
        return new PlantViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlantViewHolder holder, int position) {
        Plant plant = plantList.get(position);

        holder.commonName.setText(plant.getCommonName());
        holder.scientificName.setText(plant.getScientificName());

        Glide.with(context)
                .load(plant.getImageUrl())
                .placeholder(R.drawable.default_image)
                .error(R.drawable.error_image)
                .into(holder.plantImage);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, PlantDetailsActivity.class);
            intent.putExtra("common_name", plant.getCommonName());
            intent.putExtra("scientific_name", plant.getScientificName());
            intent.putExtra("benefits", plant.getBenefits());
            intent.putExtra("diseases_used_for", plant.getDiseasesUsedFor());
            intent.putExtra("how_to_use", plant.getHowToUse());
            intent.putExtra("image_url", plant.getImageUrl());
            context.startActivity(intent);
        });

        if (showBookmarkIcon) {
            holder.bookmarkIcon.setVisibility(View.VISIBLE);
            holder.bookmarkIcon.setOnClickListener(v -> {
                BookmarkManager.removeBookmark(context, plant.getCommonName());
                removePlant(holder.getAdapterPosition());
            });
        } else {
            holder.bookmarkIcon.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return plantList.size();
    }

    static class PlantViewHolder extends RecyclerView.ViewHolder {
        TextView commonName, scientificName;
        ImageView plantImage, bookmarkIcon;

        public PlantViewHolder(@NonNull View itemView) {
            super(itemView);
            commonName = itemView.findViewById(R.id.plant_common_name);
            scientificName = itemView.findViewById(R.id.plant_scientific_name);
            plantImage = itemView.findViewById(R.id.plant_image);
            bookmarkIcon = itemView.findViewById(R.id.bookmark_icon); // Make sure this exists in item_plant.xml
        }
    }
}
