package com.example.vanaspati;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class BookmarkManager {

    private static final String PREF_NAME = "Bookmarks";
    private static final String KEY_PLANT_LIST = "plant_list";

    public static void addBookmark(Context context, Plant plant) {
        List<Plant> bookmarks = getBookmarks(context);
        for (Plant p : bookmarks) {
            if (p.getCommonName().equals(plant.getCommonName())) return; // Avoid duplicates
        }
        bookmarks.add(plant);
        saveBookmarks(context, bookmarks);
    }

    public static void removeBookmark(Context context, String commonName) {
        List<Plant> bookmarks = getBookmarks(context);
        bookmarks.removeIf(p -> p.getCommonName().equals(commonName));
        saveBookmarks(context, bookmarks);
    }

    public static boolean isBookmarked(Context context, String commonName) {
        List<Plant> bookmarks = getBookmarks(context);
        for (Plant plant : bookmarks) {
            if (plant.getCommonName().equals(commonName)) return true;
        }
        return false;
    }

    public static List<Plant> getBookmarks(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String json = prefs.getString(KEY_PLANT_LIST, "");
        if (json.isEmpty()) return new ArrayList<>();

        Type type = new TypeToken<List<Plant>>() {}.getType();
        return new Gson().fromJson(json, type);
    }

    private static void saveBookmarks(Context context, List<Plant> bookmarks) {
        SharedPreferences.Editor editor = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit();
        String json = new Gson().toJson(bookmarks);
        editor.putString(KEY_PLANT_LIST, json);
        editor.apply();}
        public static void clearAllBookmarks(Context context) {
            saveBookmarks(context, new ArrayList<>());
        }

    }

