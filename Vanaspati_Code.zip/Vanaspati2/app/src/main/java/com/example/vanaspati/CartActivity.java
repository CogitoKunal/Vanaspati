package com.example.vanaspati;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.util.List;

public class CartActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CartAdapter adapter;
    private LinearLayout checkoutContainer;
    private TextView emptyCartText, totalItemsText, cartBadge;
    private Button checkoutButton; // Added

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        // Initialize all views after setting the content view
        cartBadge = findViewById(R.id.cart_badge);
        recyclerView = findViewById(R.id.cart_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        checkoutContainer = findViewById(R.id.checkout_container);
        emptyCartText = findViewById(R.id.empty_cart_text);
        totalItemsText = findViewById(R.id.total_items_text);
        checkoutButton = findViewById(R.id.checkout_button); // Added

        ImageView navHome = findViewById(R.id.nav_homes);
        ImageView navBookmark = findViewById(R.id.nav_bookmarks);
        ImageView navCart = findViewById(R.id.nav_carts);
        ImageView navSettings = findViewById(R.id.nav_settings);

        navHome.setOnClickListener(v -> {
            startActivity(new Intent(CartActivity.this, HomePageActivity.class));
            overridePendingTransition(0, 0);
        });

        navBookmark.setOnClickListener(v -> {
            startActivity(new Intent(CartActivity.this, BookmarkActivity.class));
            overridePendingTransition(0, 0);
        });

        navCart.setOnClickListener(v -> {
            Toast.makeText(this, "You're already on Cart Page", Toast.LENGTH_SHORT).show();
        });

        navSettings.setOnClickListener(v -> {
            startActivity(new Intent(CartActivity.this, SettingsPageActivity.class));
            overridePendingTransition(0, 0);
        });

        // Checkout button click handler
        checkoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(CartActivity.this, CheckoutActivity.class);
            startActivity(intent);
        });

        List<CartItem> cartItems = CartManager.getCartItems(this);

        adapter = new CartAdapter(cartItems, this, updatedCart -> {
            updateCartUI(updatedCart);
            updateBadge(updatedCart);
        });

        recyclerView.setAdapter(adapter);

        // Initial UI Update
        updateCartUI(cartItems);
        updateBadge(cartItems);
    }

    @Override
    protected void onResume() {
        super.onResume();
        List<CartItem> cartItems = CartManager.getCartItems(this);
        updateCartUI(cartItems);
        updateBadge(cartItems);
    }

    private void updateCartUI(List<CartItem> cartItems) {
        if (cartItems == null || cartItems.isEmpty()) {
            checkoutContainer.setVisibility(View.GONE);
            emptyCartText.setVisibility(View.VISIBLE);
        } else {
            checkoutContainer.setVisibility(View.VISIBLE);
            emptyCartText.setVisibility(View.GONE);

            int totalItems = 0;
            for (CartItem item : cartItems) {
                totalItems += item.getQuantity();
            }

            totalItemsText.setText("Total: " + totalItems + " items");
        }
    }

    private void updateBadge(List<CartItem> cartItems) {
        if (cartBadge == null) return;

        int totalItems = 0;
        for (CartItem item : cartItems) {
            totalItems += item.getQuantity();
        }

        if (totalItems > 0) {
            cartBadge.setVisibility(View.VISIBLE);
            cartBadge.setText(String.valueOf(totalItems));
        } else {
            cartBadge.setVisibility(View.GONE);
        }
    }
}
