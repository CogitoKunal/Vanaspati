package com.example.vanaspati;

public class Request {
    public String userId;
    public String doctorId;
    public String type;

    public Request() {}  // Required for Firebase

    public Request(String userId, String doctorId, String type) {
        this.userId = userId;
        this.doctorId = doctorId;
        this.type = type;
    }
}
