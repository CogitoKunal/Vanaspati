package com.example.vanaspati;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CheckoutActivity extends AppCompatActivity {

    private RecyclerView cartRecyclerView;
    private TextView checkoutTotalTextView;
    private Button confirmOrderButton;
    private LinearLayout checkoutSection;

    private List<CartItem> cartItems;
    private CartAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        cartRecyclerView = findViewById(R.id.cartRecyclerView);
        checkoutTotalTextView = findViewById(R.id.totalItemsText);
        confirmOrderButton = findViewById(R.id.confirmOrderButton);
        checkoutSection = findViewById(R.id.checkout_section);
        cartItems = CartManager.getCartItems(this);

        adapter = new CartAdapter(cartItems, this, updatedCart -> {
            cartItems = updatedCart;
            updateCheckoutUI();
        });

        cartRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        cartRecyclerView.setAdapter(adapter);

        updateCheckoutUI();

        confirmOrderButton.setOnClickListener(v -> {
            // Clear the cart, since the order is confirmed
            CartManager.clearCart(CheckoutActivity.this);

            // Redirect to UserDetailsActivity for entering user details
            startActivity(new Intent(CheckoutActivity.this, UserDetailsActivity.class));
            finish(); // Close the CheckoutActivity
        });
    }

    private void updateCheckoutUI() {
        int itemCount = cartItems.size();
        double totalPrice = 0.0;

        for (CartItem item : cartItems) {
            try {
                // Check if price is not null or empty
                String priceString = item.getPlant().getPrice();
                if (priceString != null && !priceString.trim().isEmpty()) {
                    double price = Double.parseDouble(priceString);
                    totalPrice += price * item.getQuantity();
                } else {
                    // Handle the case where price is null or empty
                    String plantName = item.getPlant().getCommonName();
                    Log.e("CheckoutActivity", "Invalid price for item: " + plantName);
                    Toast.makeText(this, "Invalid price for item: " + plantName, Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Log.e("CheckoutActivity", "Error parsing price: " + item.getPlant().getPrice(), e);
                Toast.makeText(this, "Error processing item price", Toast.LENGTH_SHORT).show();
            }
        }

        if (itemCount > 0) {
            checkoutSection.setVisibility(View.VISIBLE);
            checkoutTotalTextView.setText(getString(R.string.total_price, itemCount, totalPrice));
        } else {
            checkoutSection.setVisibility(View.GONE);
        }
    }
}
