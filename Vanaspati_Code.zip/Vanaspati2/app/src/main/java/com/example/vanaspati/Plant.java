package com.example.vanaspati;

import java.io.Serializable;

public class Plant implements Serializable {
    private String commonName;
    private String scientificName;
    private String benefits;
    private String diseasesUsedFor;
    private String howToUse;
    private String imageUrl;
    private String price;

    // Default constructor (required for serialization and Firebase, etc.)
    public Plant() {
    }

    // Full constructor
    public Plant(String commonName, String scientificName, String benefits,
                 String diseasesUsedFor, String howToUse, String imageUrl) {
        this.commonName = commonName;
        this.scientificName = scientificName;
        this.benefits = benefits;
        this.diseasesUsedFor = diseasesUsedFor;
        this.howToUse = howToUse;
        this.imageUrl = imageUrl;
    }

    // Getters
    public String getCommonName() {
        return commonName;
    }

    public String getScientificName() {
        return scientificName;
    }

    public String getBenefits() {
        return benefits;
    }

    public String getDiseasesUsedFor() {
        return diseasesUsedFor;
    }

    public String getHowToUse() {
        return howToUse;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    // Setters
    public void setCommonName(String commonName) {
        this.commonName = commonName;
    }

    public void setScientificName(String scientificName) {
        this.scientificName = scientificName;
    }

    public void setBenefits(String benefits) {
        this.benefits = benefits;
    }

    public void setDiseasesUsedFor(String diseasesUsedFor) {
        this.diseasesUsedFor = diseasesUsedFor;
    }

    public void setHowToUse(String howToUse) {
        this.howToUse = howToUse;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    // Optional: helpful for logging/debugging
    @Override
    public String toString() {
        return "Plant{" +
                "commonName='" + commonName + '\'' +
                ", scientificName='" + scientificName + '\'' +
                ", benefits='" + benefits + '\'' +
                ", diseasesUsedFor='" + diseasesUsedFor + '\'' +
                ", howToUse='" + howToUse + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                '}';
    }

    public String getPrice() {
        return price;

    }
}
