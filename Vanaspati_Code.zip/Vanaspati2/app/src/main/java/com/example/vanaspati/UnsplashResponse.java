package com.example.vanaspati;

import java.util.List;

public class UnsplashResponse {
    private List<Result> results;

    public List<Result> getResults() {
        return results;
    }

    public static class Result {
        private Urls urls;

        public Urls getUrls() {
            return urls;
        }
    }

    public static class Urls {
        private String regular;

        public String getRegular() {
            return regular;
        }
    }
}
