package com.example.vanaspati;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DoctorAdapter extends RecyclerView.Adapter<DoctorAdapter.DoctorViewHolder> {
    private List<Doctor> doctorList;
    private Context context;
    private OnDoctorActionListener actionListener;

    public DoctorAdapter(List<Doctor> doctorList, Context context, OnDoctorActionListener actionListener) {
        this.doctorList = doctorList;
        this.context = context;
        this.actionListener = actionListener;
    }

    @Override
    public DoctorViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_doctor, parent, false);
        return new DoctorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(DoctorViewHolder holder, int position) {
        Doctor doctor = doctorList.get(position);

        holder.name.setText(doctor.getName());
        holder.specialization.setText(doctor.getSpecialization());
        holder.availability.setText(doctor.isAvailable() ? "Available" : "Not Available");
        holder.availability.setTextColor(doctor.isAvailable() ? 0xFF4CAF50 : 0xFFF44336);

        holder.btnConsult.setOnClickListener(v -> {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

            Map<String, Object> chatRequest = new HashMap<>();
            chatRequest.put("type", "chat");
            chatRequest.put("userId", userId);
            chatRequest.put("doctorId", doctor.getId());
            chatRequest.put("doctorName", doctor.getName());
            chatRequest.put("timestamp", System.currentTimeMillis());

            db.collection("consultation_requests")
                    .add(chatRequest)
                    .addOnSuccessListener(documentReference -> {
                        Intent intent = new Intent(context, ChatActivity.class);
                        intent.putExtra("doctorId", doctor.getId());
                        intent.putExtra("doctorName", doctor.getName());
                        context.startActivity(intent);
                    });
        });

        holder.btnVideoCall.setOnClickListener(v -> {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            String channelName = userId + "_" + doctor.getId(); // More unique than just doctorId

            Map<String, Object> videoCallRequest = new HashMap<>();
            videoCallRequest.put("type", "video");
            videoCallRequest.put("userId", userId);
            videoCallRequest.put("doctorId", doctor.getId());
            videoCallRequest.put("doctorName", doctor.getName());
            videoCallRequest.put("channelName", channelName);
            videoCallRequest.put("timestamp", FieldValue.serverTimestamp());
            videoCallRequest.put("status", "initiated");

            db.collection("videoCalls")
                    .document(channelName)
                    .set(videoCallRequest)
                    .addOnSuccessListener(unused -> {
                        Intent intent = new Intent(context, VideoCallActivity.class);
                        intent.putExtra("roomName", channelName);
                        context.startActivity(intent);
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(context, "Failed to initiate call: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        });
    }

    @Override
    public int getItemCount() {
        return doctorList != null ? doctorList.size() : 0;
    }

    public static class DoctorViewHolder extends RecyclerView.ViewHolder {
        TextView name, specialization, availability;
        Button btnConsult, btnVideoCall;

        public DoctorViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.doctorNameItem);
            specialization = itemView.findViewById(R.id.doctorSpecializationItem);
            availability = itemView.findViewById(R.id.doctorAvailabilityItem);
            btnConsult = itemView.findViewById(R.id.btnConsultDoctorItem);
            btnVideoCall = itemView.findViewById(R.id.btnVideoCallItem);
        }
    }

    public interface OnDoctorActionListener {
        void onChatRequested(Doctor doctor);
        void onVideoCallRequested(Doctor doctor);
    }
}
