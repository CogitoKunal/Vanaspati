package com.example.vanaspati;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    private List<CartItem> cartItems;
    private Context context;
    private OnCartUpdatedListener listener;

    public interface OnCartUpdatedListener {
        void onCartUpdated(List<CartItem> updatedCart);
    }

    public CartAdapter(List<CartItem> cartItems, Context context, OnCartUpdatedListener listener) {
        this.cartItems = cartItems;
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = cartItems.get(position);

        holder.nameTextView.setText(item.getPlant().getCommonName());
        holder.priceTextView.setText("₹" + item.getPlant().getPrice());
        holder.quantityEditText.setText(String.valueOf(item.getQuantity()));

        Glide.with(context)
                .load(item.getPlant().getImageUrl())
                .placeholder(R.drawable.default_image)
                .error(R.drawable.error_image)
                .into(holder.imageView);

        holder.removeButton.setOnClickListener(v -> {
            CartManager.removeFromCart(context, item);
            cartItems = CartManager.getCartItems(context);
            notifyDataSetChanged();
            listener.onCartUpdated(cartItems);
        });

        // Quantity increase
        holder.plusButton.setOnClickListener(v -> {
            int qty = item.getQuantity() + 1;
            item.setQuantity(qty);
            CartManager.updateCartItem(context, item);
            holder.quantityEditText.setText(String.valueOf(qty));
            listener.onCartUpdated(cartItems); // Notify on update
        });

        // Quantity decrease
        holder.minusButton.setOnClickListener(v -> {
            int qty = item.getQuantity();
            if (qty > 1) {
                item.setQuantity(qty - 1);
                CartManager.updateCartItem(context, item);
                holder.quantityEditText.setText(String.valueOf(qty - 1));
                listener.onCartUpdated(cartItems); // Notify on update
            } else {
                Toast.makeText(context, "Minimum quantity is 1", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle keyboard input
        holder.quantityEditText.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                try {
                    int qty = Integer.parseInt(s.toString());
                    if (qty > 0) {
                        item.setQuantity(qty);
                        CartManager.updateCartItem(context, item);
                        listener.onCartUpdated(cartItems); // Notify on update
                    }
                } catch (NumberFormatException ignored) {}
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    static class CartViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView, priceTextView;
        ImageView imageView;
        EditText quantityEditText;
        ImageView plusButton, minusButton;
        Button removeButton;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.cart_item_name);
            priceTextView = itemView.findViewById(R.id.cart_item_price);
            quantityEditText = itemView.findViewById(R.id.cart_quantity_input);
            plusButton = itemView.findViewById(R.id.plus_button);
            minusButton = itemView.findViewById(R.id.minus_button);
            imageView = itemView.findViewById(R.id.cart_item_image);
            removeButton = itemView.findViewById(R.id.remove_button);
        }
    }
}
