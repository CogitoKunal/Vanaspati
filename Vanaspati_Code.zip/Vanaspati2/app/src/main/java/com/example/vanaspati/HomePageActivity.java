package com.example.vanaspati;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class HomePageActivity extends AppCompatActivity {

    // Plant data lists and adapters
    private List<Plant> plantList = new ArrayList<>();
    private List<Plant> exploreMoreList = new ArrayList<>();
    private PlantAdapter plantAdapter;
    private ImageView virtualTourImage;
    private PlantAdapter exploreMoreAdapter;

    // Views
    private RecyclerView singlePlantRecyclerView;
    private RecyclerView exploreMoreRecyclerView;
    private AutoCompleteTextView searchBar;
    private TextView cartBadge;
    private ImageView chatbotIcon;

    private TextView emptyCartText;

    // Counters for loading plant data
    private int totalPlantsToLoad = 0;
    private int loadedPlantCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepage_scroll);
        chatbotIcon = findViewById(R.id.chatbotIcon);
        chatbotIcon.setOnClickListener(v -> {
            Intent intent = new Intent(HomePageActivity.this, ChatbotActivity.class);
            startActivity(intent);
        });


        // Set welcome text from intent or Firebase
        TextView welcomeText = findViewById(R.id.welcome_text);
        String userName = getIntent().getStringExtra("userName");

        if (userName != null && !userName.isEmpty()) {
            welcomeText.setText("Welcome to VANASPATI, " + userName);
        } else {
            FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
            if (currentUser != null) {
                FirebaseFirestore.getInstance()
                        .collection("users")
                        .document(currentUser.getUid())
                        .get()
                        .addOnSuccessListener(documentSnapshot -> {
                            if (documentSnapshot.exists() && documentSnapshot.contains("name")) {
                                String fetchedName = documentSnapshot.getString("name");
                                welcomeText.setText("Welcome to VANASPATI, " + fetchedName);
                            }
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(this, "Failed to load user name", Toast.LENGTH_SHORT).show();
                        });
            }
        }

        // Initialize views
        searchBar = findViewById(R.id.search_bar);
        singlePlantRecyclerView = findViewById(R.id.single_plant_recycler_view);
        exploreMoreRecyclerView = findViewById(R.id.explore_more_recycler_view);
        cartBadge = findViewById(R.id.cart_badge);
        emptyCartText = findViewById(R.id.empty_cart_text);
        virtualTourImage = findViewById(R.id.virtual_tour_image);
        virtualTourImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent to navigate to DoctorListActivity
                Intent intent = new Intent(HomePageActivity.this, DoctorListActivity.class);
                startActivity(intent);  // Start the DoctorListActivity
            }
        });
        // Initialize adapters
        plantAdapter = new PlantAdapter(this, new ArrayList<>());
        exploreMoreAdapter = new PlantAdapter(this, exploreMoreList);

        // Set up RecyclerViews
        setupRecyclerView(singlePlantRecyclerView, plantAdapter);
        setupRecyclerView(exploreMoreRecyclerView, exploreMoreAdapter);

        // Load plant data
        loadPlantData();

        // Set up search behavior
        findViewById(R.id.search_icon).setOnClickListener(v -> searchPlant());
        searchBar.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                searchPlant();
                return true;
            }
            return false;
        });

        // Bottom navigation click handlers
        findViewById(R.id.nav_cart).setOnClickListener(v -> {
            if (CartManager.getCartItems(this).isEmpty()) {
                Toast.makeText(this, "Your cart is empty.", Toast.LENGTH_SHORT).show();
            } else {
                openCartActivity();
            }
        });
        findViewById(R.id.nav_bookmark).setOnClickListener(v -> openBookmarkPage());
        findViewById(R.id.nav_home).setOnClickListener(v -> Toast.makeText(this, "You are already on the Home Page.", Toast.LENGTH_SHORT).show());
        findViewById(R.id.nav_settings).setOnClickListener(v -> openSettingsPage());
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCartBadge();
    }

    // Update cart badge visibility
    private void updateCartBadge() {
        int itemCount = CartManager.getCartItems(this).size();
        if (itemCount > 0) {
            cartBadge.setVisibility(View.VISIBLE);
            cartBadge.setBackgroundResource(R.drawable.badge_background);
            cartBadge.setText("");
        } else {
            cartBadge.setVisibility(View.GONE);
        }
    }

    // Navigation methods
    private void openCartActivity() {
        Intent intent = new Intent(this, CartActivity.class);
        startActivity(intent);
    }

    private void openBookmarkPage() {
        Intent intent = new Intent(this, BookmarkActivity.class);
        startActivity(intent);
    }

    private void openSettingsPage() {
        Intent intent = new Intent(this, SettingsPageActivity.class);
        startActivity(intent);
    }

    // RecyclerView configuration
    private void setupRecyclerView(RecyclerView recyclerView, PlantAdapter adapter) {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
        SnapHelper snapHelper = new LinearSnapHelper();
        if (recyclerView.getOnFlingListener() == null) {
            snapHelper.attachToRecyclerView(recyclerView);
        }
    }

    // Load plant data from local JSON and fetch image from Unsplash
    private void loadPlantData() {
        try {
            InputStream inputStream = getAssets().open("PlantData.json");
            byte[] buffer = new byte[inputStream.available()];
            inputStream.read(buffer);
            inputStream.close();

            String json = new String(buffer, "UTF-8");
            JSONArray jsonArray = new JSONArray(json);
            totalPlantsToLoad = jsonArray.length();

            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl("https://api.unsplash.com/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            UnsplashApi unsplashApi = retrofit.create(UnsplashApi.class);

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);

                String commonName = obj.optString("common_name", "N/A");
                String scientificName = obj.optString("scientific_name", "N/A");
                String benefits = obj.optString("benefits", "N/A");
                String diseasesUsedFor = obj.optString("diseases_used_for", "N/A");
                String howToUse = obj.optString("how_to_use", "Not specified");
                String imageFilename = obj.optString("image_filename", "https://via.placeholder.com/150");

                Call<UnsplashResponse> call = unsplashApi.searchPhotos(commonName, "QZZUchgyenC37FN5JwC-1x5xHdu_wn6MgL6SxLUNLWs");

                String finalCommonName = commonName;
                call.enqueue(new Callback<UnsplashResponse>() {
                    @Override
                    public void onResponse(Call<UnsplashResponse> call, Response<UnsplashResponse> response) {
                        String imageUrl = imageFilename;
                        if (response.body() != null && response.body().getResults().size() > 0) {
                            imageUrl = response.body().getResults().get(0).getUrls().getRegular();
                        }
                        addPlantToList(new Plant(finalCommonName, scientificName, benefits, diseasesUsedFor, howToUse, imageUrl));
                    }

                    @Override
                    public void onFailure(Call<UnsplashResponse> call, Throwable t) {
                        t.printStackTrace();
                        addPlantToList(new Plant(finalCommonName, scientificName, benefits, diseasesUsedFor, howToUse, "https://via.placeholder.com/150"));
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("PlantDataError", "Error loading plant data: " + e.getMessage());
        }
    }

    // Add plant to list and update UI once all are loaded
    private void addPlantToList(Plant plant) {
        plantList.add(plant);
        plantAdapter.updateList(new ArrayList<>(plantList));

        loadedPlantCount++;
        if (loadedPlantCount == totalPlantsToLoad) {
            loadExploreMoreData();

            List<String> plantNames = new ArrayList<>();
            for (Plant p : plantList) {
                plantNames.add(p.getCommonName());
            }
            ArrayAdapter<String> suggestionAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, plantNames);
            searchBar.setAdapter(suggestionAdapter);
            searchBar.setThreshold(4);

            searchBar.setOnFocusChangeListener((v, hasFocus) -> {
                if (hasFocus && searchBar.getText().length() >= 3) {
                    searchBar.showDropDown();
                }
            });
        }
    }

    // Populate "Explore More" section with random plants
    private void loadExploreMoreData() {
        exploreMoreList.clear();
        Collections.shuffle(plantList);
        int exploreCount = Math.min(6, plantList.size());
        for (int i = 0; i < exploreCount; i++) {
            exploreMoreList.add(plantList.get(i));
        }
        exploreMoreAdapter.notifyDataSetChanged();
    }

    // Filter plant list by search query
    private void searchPlant() {
        String query = searchBar.getText().toString().trim().toLowerCase();
        if (query.isEmpty()) {
            plantAdapter.updateList(new ArrayList<>(plantList));
            return;
        }

        List<Plant> filteredList = new ArrayList<>();
        for (Plant plant : plantList) {
            if (plant.getCommonName().toLowerCase().contains(query)) {
                filteredList.add(plant);
            }
        }

        if (filteredList.isEmpty()) {
            Toast.makeText(this, "No plants found", Toast.LENGTH_SHORT).show();
        }

        plantAdapter.updateList(filteredList);
    }
}
