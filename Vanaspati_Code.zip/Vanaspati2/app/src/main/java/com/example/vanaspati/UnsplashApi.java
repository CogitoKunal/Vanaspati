package com.example.vanaspati;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface UnsplashApi {
    @GET("/search/photos")
    Call<UnsplashResponse> searchPhotos(
            @Query("query") String query, // Search query (e.g., plant name)
            @Query("client_id") String clientId // Unsplash API key embedded
    );

    // Updated Version - Directly Using Your API Key
    @GET("/search/photos")
    Call<UnsplashResponse> searchPhotosPre(
    );
}
