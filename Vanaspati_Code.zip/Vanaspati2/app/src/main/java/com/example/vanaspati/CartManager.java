package com.example.vanaspati;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class CartManager {

    private static final String CART_PREFS = "cart_preferences";
    private static final String CART_KEY = "cart_items";

    private static final Gson gson = new Gson();

    // ✅ Add plant to cart (merge quantity if plant exists)
    public static void addToCart(Context context, Plant plant, int quantity) {
        List<CartItem> cart = getCartItems(context);
        boolean found = false;
        for (CartItem item : cart) {
            if (item.getPlant().getCommonName().equals(plant.getCommonName())) {
                item.setQuantity(item.getQuantity() + quantity);
                found = true;
                break;
            }
        }
        if (!found) {
            cart.add(new CartItem(plant, quantity));
        }
        saveCart(context, cart);
    }
    

    // ✅ Remove item from cart
    public static void removeFromCart(Context context, CartItem item) {
        List<CartItem> cart = getCartItems(context);
        cart.removeIf(cartItem -> cartItem.getPlant().getCommonName().equals(item.getPlant().getCommonName()));
        saveCart(context, cart);
    }

    // ✅ Get all cart items
    public static List<CartItem> getCartItems(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(CART_PREFS, Context.MODE_PRIVATE);
        String json = prefs.getString(CART_KEY, null);
        if (json != null) {
            Type type = new TypeToken<List<CartItem>>() {}.getType();
            return gson.fromJson(json, type);
        }
        return new ArrayList<>();
    }

    // ✅ Update specific item
    public static void updateCartItem(Context context, CartItem updatedItem) {
        List<CartItem> currentCart = getCartItems(context);
        for (int i = 0; i < currentCart.size(); i++) {
            CartItem item = currentCart.get(i);
            if (item.getPlant().getCommonName().equals(updatedItem.getPlant().getCommonName())) {
                currentCart.set(i, updatedItem);
                break;
            }
        }
        saveCart(context, currentCart);
    }

    // ✅ Save cart
    public static void saveCart(Context context, List<CartItem> cartItems) {
        SharedPreferences prefs = context.getSharedPreferences(CART_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        String json = gson.toJson(cartItems);
        editor.putString(CART_KEY, json);
        editor.apply();
    }

    // ✅ Clear cart
    public static void clearCart(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(CART_PREFS, Context.MODE_PRIVATE);
        prefs.edit().clear().apply();
    }


}
