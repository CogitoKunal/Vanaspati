package com.example.vanaspati;

public class CartItem {
    private Plant plant;
    private int quantity;

    public CartItem(Plant plant, int quantity) {
        this.plant = plant;
        this.quantity = quantity;
    }

    public Plant getPlant() {
        return plant;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
