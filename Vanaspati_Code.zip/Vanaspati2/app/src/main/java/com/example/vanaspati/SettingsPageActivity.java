package com.example.vanaspati;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.firebase.auth.FirebaseAuth;

public class SettingsPageActivity extends AppCompatActivity {

    private Switch darkModeSwitch;
    private SharedPreferences preferences;
    private TextView cartBadge;
    private static final String PREFS_NAME = "app_settings";
    private static final String DARK_MODE_KEY = "dark_mode";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_page);

        preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
// Using the class-level cartBadge variable
        cartBadge = findViewById(R.id.cart_badge);

        // Check cart items count and update badge visibility
        int itemCount = CartManager.getCartItems(this).size();
        if (itemCount > 0) {
            cartBadge.setVisibility(View.VISIBLE);
            cartBadge.setBackgroundResource(R.drawable.badge_background); // Set the custom badge background
            cartBadge.setText(""); // Clear the text to not show any number
        } else {
            cartBadge.setVisibility(View.GONE); // Hide if no items in cart
        }


        // Dark Mode
        darkModeSwitch = findViewById(R.id.switch_dark_mode);
        boolean isDarkMode = preferences.getBoolean(DARK_MODE_KEY, false);
        darkModeSwitch.setChecked(isDarkMode);
        applyDarkMode(isDarkMode);

        darkModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            applyDarkMode(isChecked);
            preferences.edit().putBoolean(DARK_MODE_KEY, isChecked).apply();
        });

        // Clear Bookmarks
        TextView clearBookmarks = findViewById(R.id.clear_bookmarks);
        clearBookmarks.setOnClickListener(v -> {
            BookmarkManager.clearAllBookmarks(this);
            Toast.makeText(this, "All bookmarks cleared", Toast.LENGTH_SHORT).show();
        });
        // Bottom Navigation Item Click Listeners
        findViewById(R.id.nav_home).setOnClickListener(v -> {
            startActivity(new Intent(this, HomePageActivity.class));
            overridePendingTransition(0, 0);
        });

        findViewById(R.id.nav_bookmark).setOnClickListener(v -> {
            startActivity(new Intent(this, BookmarkActivity.class));
            overridePendingTransition(0, 0);
        });

        findViewById(R.id.nav_cart).setOnClickListener(v -> {
            // You can implement cart functionality later
            startActivity(new Intent(this, CartActivity.class));
            overridePendingTransition(0, 0);
        });

        findViewById(R.id.nav_settings).setOnClickListener(v -> {
            Toast.makeText(this, "You're already on Settings", Toast.LENGTH_SHORT).show();
        });


        // About App
        TextView aboutApp = findViewById(R.id.about_app);
        aboutApp.setOnClickListener(v -> {
            String aboutText = "Hey there! 👋\n\n" +
                    "Thank you for using Vanaspati 🌿\n\n" +
                    "This app is crafted with love to help you explore the healing world of medicinal plants. Whether you're curious, learning, or just love nature — you're in the right place.\n\n" +
                    "Your support means everything.\n\n" +
                    "~ Kunal 🌱";

            new AlertDialog.Builder(this)
                    .setTitle("About Vanaspati")
                    .setMessage(aboutText)
                    .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                    .show();
        });

        // Send Feedback
        TextView sendFeedback = findViewById(R.id.send_feedback);
        sendFeedback.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:kunal.nagar.313@gmail.com"));
            intent.putExtra(Intent.EXTRA_SUBJECT, "Vanaspati App Feedback");
            startActivity(Intent.createChooser(intent, "Send Feedback"));
        });

        // Logout
        TextView logoutText = findViewById(R.id.logout_text);
        logoutText.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Logout")
                    .setMessage("Are you sure you want to logout?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        FirebaseAuth.getInstance().signOut();
                        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(this, LoginActivity.class));
                        finish();
                    })
                    .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                    .show();
        });
    }

    private void applyDarkMode(boolean enable) {
        AppCompatDelegate.setDefaultNightMode(
                enable ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
        );
    }
}
