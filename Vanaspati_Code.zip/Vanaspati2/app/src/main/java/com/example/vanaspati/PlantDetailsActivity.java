package com.example.vanaspati;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class PlantDetailsActivity extends AppCompatActivity {

    private static final String UNSPLASH_API_KEY = "QZZUchgyenC37FN5JwC-1x5xHdu_wn6MgL6SxLUNLWs";

    private ImageView bookmarkIcon;
    private TextView cartBadge;
    private String commonName;
    private Plant currentPlant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plant_details);
        cartBadge = findViewById(R.id.cart_badge);

        // Check cart items count and update badge visibility
        int itemCount = CartManager.getCartItems(this).size();
        if (itemCount > 0) {
            cartBadge.setVisibility(View.VISIBLE);
            cartBadge.setBackgroundResource(R.drawable.badge_background); // Set the custom badge background
            cartBadge.setText(""); // Clear the text to not show any number
        } else {
            cartBadge.setVisibility(View.GONE); // Hide if no items in cart
        }


        // Bind views
        ImageView plantImage = findViewById(R.id.plant_image);
        bookmarkIcon = findViewById(R.id.bookmark_icon);
        TextView commonNameTextView = findViewById(R.id.plant_common_name);
        TextView scientificNameTextView = findViewById(R.id.plant_scientific_name);
        TextView benefitsTextView = findViewById(R.id.plant_benefits);
        TextView diseasesTextView = findViewById(R.id.plant_diseases);
        TextView howToUseTextView = findViewById(R.id.plant_how_to_use);
        EditText quantityInput = findViewById(R.id.quantityInput);
        Button addToCartButton = findViewById(R.id.addToCartButton);
        ImageButton increaseButton = findViewById(R.id.increaseQuantityButton);
        ImageButton decreaseButton = findViewById(R.id.decreaseQuantityButton);
        quantityInput.setText("1");
// Increase button logic
        increaseButton.setOnClickListener(v -> {
            String currentText = quantityInput.getText().toString();
            int quantity = currentText.isEmpty() ? 1 : Integer.parseInt(currentText);
            quantityInput.setText(String.valueOf(quantity + 1));
        });

// Decrease button logic
        decreaseButton.setOnClickListener(v -> {
            String currentText = quantityInput.getText().toString();
            int quantity = currentText.isEmpty() ? 1 : Integer.parseInt(currentText);
            if (quantity > 1) {
                quantityInput.setText(String.valueOf(quantity - 1));
            } else {
                Toast.makeText(this, "Minimum quantity is 1", Toast.LENGTH_SHORT).show();
            }
        });
        // Make image square
        FrameLayout imageContainer = findViewById(R.id.image_container);
        imageContainer.post(() -> {
            int width = imageContainer.getWidth();
            ViewGroup.LayoutParams params = imageContainer.getLayoutParams();
            params.height = width; // Make it square
            imageContainer.setLayoutParams(params);
        });

        // Bottom Navigation Click Handling
        findViewById(R.id.nav_home).setOnClickListener(v -> {
            startActivity(new Intent(this, HomePageActivity.class));
            overridePendingTransition(0, 0);
        });

        findViewById(R.id.nav_bookmark).setOnClickListener(v -> {
            startActivity(new Intent(this, BookmarkActivity.class));
            overridePendingTransition(0, 0);
        });

        findViewById(R.id.nav_cart).setOnClickListener(v -> {
            startActivity(new Intent(this, CartActivity.class));
            overridePendingTransition(0, 0);
        });

        findViewById(R.id.nav_settings).setOnClickListener(v -> {
            startActivity(new Intent(this, SettingsPageActivity.class));
            overridePendingTransition(0, 0);
        });

        // Get data from intent
        commonName = getIntent().getStringExtra("common_name");
        String scientificName = getIntent().getStringExtra("scientific_name");
        String benefits = getIntent().getStringExtra("benefits");
        String diseases = getIntent().getStringExtra("diseases_used_for");
        String howToUse = getIntent().getStringExtra("how_to_use");
        String imageUrl = getIntent().getStringExtra("image_url");

        // Set data to views
        commonNameTextView.setText(commonName);
        scientificNameTextView.setText(scientificName);
        benefitsTextView.setText(benefits);
        diseasesTextView.setText(diseases);
        howToUseTextView.setText(howToUse);

        // Prepare current Plant object
        currentPlant = new Plant(commonName, scientificName, benefits, diseases, howToUse, imageUrl);

        // Load image
        if (imageUrl != null && !imageUrl.isEmpty()) {
            Glide.with(this)
                    .load(imageUrl)
                    .placeholder(R.drawable.default_image)
                    .error(R.drawable.error_image)
                    .into(plantImage);
        } else {
            fetchImageFromUnsplash(commonName, plantImage);
        }

        // Set initial bookmark icon
        updateBookmarkIcon();

        // Toggle bookmark on icon click
        bookmarkIcon.setOnClickListener(v -> {
            if (BookmarkManager.isBookmarked(this, commonName)) {
                BookmarkManager.removeBookmark(this, commonName);
                Toast.makeText(this, "Removed from bookmarks", Toast.LENGTH_SHORT).show();
            } else {
                BookmarkManager.addBookmark(this, currentPlant);
                Toast.makeText(this, "Bookmarked!", Toast.LENGTH_SHORT).show();
            }
            updateBookmarkIcon();
        });

        // Add to Cart button logic
        addToCartButton.setOnClickListener(v -> {
            String quantityStr = quantityInput.getText().toString();
            if (quantityStr.isEmpty()) {
                Toast.makeText(this, "Please enter quantity", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent("cart_updated");
                sendBroadcast(intent);
                return;
            }

            int quantity = Integer.parseInt(quantityStr);
            if (quantity <= 0) {
                Toast.makeText(this, "Quantity must be at least 1", Toast.LENGTH_SHORT).show();
                return;
            }

            CartManager.addToCart(this, currentPlant, quantity); // Pass context here
            Toast.makeText(this, "Added to cart", Toast.LENGTH_SHORT).show();
        });
    }

    // Update bookmark icon based on whether the plant is bookmarked or not
    private void updateBookmarkIcon() {
        if (BookmarkManager.isBookmarked(this, commonName)) {
            bookmarkIcon.setImageResource(R.drawable.ic_bookmarked);
        } else {
            bookmarkIcon.setImageResource(R.drawable.ic_bookmark_border);
        }
    }

    // Fetch image from Unsplash API if no local image URL is available
    private void fetchImageFromUnsplash(String query, ImageView plantImage) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.unsplash.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        UnsplashApi unsplashApi = retrofit.create(UnsplashApi.class);
        Call<UnsplashResponse> call = unsplashApi.searchPhotos(query, UNSPLASH_API_KEY);
        call.enqueue(new Callback<UnsplashResponse>() {
            @Override
            public void onResponse(Call<UnsplashResponse> call, Response<UnsplashResponse> response) {
                if (response.isSuccessful() && response.body() != null && !response.body().getResults().isEmpty()) {
                    String imageUrl = response.body().getResults().get(0).getUrls().getRegular();
                    currentPlant.setImageUrl(imageUrl); // Update Plant object with URL

                    Glide.with(PlantDetailsActivity.this)
                            .load(imageUrl)
                            .placeholder(R.drawable.default_image)
                            .error(R.drawable.error_image)
                            .into(plantImage);
                } else {
                    Toast.makeText(PlantDetailsActivity.this, "No image found.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UnsplashResponse> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(PlantDetailsActivity.this, "Failed to load image.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
