package com.example.vanaspati;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class UserDetailsActivity extends AppCompatActivity {

    private EditText etName, etMobile, etAddress;
    private Button btnPlaceOrder;

    private SharedPreferences sharedPreferences;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);

        etName = findViewById(R.id.et_name);
        etMobile = findViewById(R.id.et_mobile);
        etAddress = findViewById(R.id.et_address);
        btnPlaceOrder = findViewById(R.id.btn_place_order);

        sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);
        db = FirebaseFirestore.getInstance();

        // Pre-fill saved data if available
        etName.setText(sharedPreferences.getString("name", ""));
        etMobile.setText(sharedPreferences.getString("mobile", ""));
        etAddress.setText(sharedPreferences.getString("address", ""));

        btnPlaceOrder.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String mobile = etMobile.getText().toString().trim();
            String address = etAddress.getText().toString().trim();

            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(mobile) || TextUtils.isEmpty(address)) {
                Toast.makeText(this, "Please fill all details", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save user data in SharedPreferences
            sharedPreferences.edit()
                    .putString("name", name)
                    .putString("mobile", mobile)
                    .putString("address", address)
                    .apply();

            // Create a User object
            User user = new User(name, mobile, address);

            // Prepare order data
            Map<String, Object> orderData = new HashMap<>();
            orderData.put("user", user);  // Save the User object in the order data
            orderData.put("timestamp", System.currentTimeMillis());
            orderData.put("items", CartManager.getCartItems(this));

            // Store in Firestore
            db.collection("orders")
                    .add(orderData)
                    .addOnSuccessListener(documentReference -> {
                        Toast.makeText(this, "Order placed successfully!", Toast.LENGTH_LONG).show();
                        CartManager.clearCart(this); // Clear cart after order is placed
                        startActivity(new Intent(this, HomePageActivity.class)); // Redirect to HomePageActivity
                        finish(); // Close UserDetailsActivity
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed to place order. Try again!", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    });
        });
    }
}
