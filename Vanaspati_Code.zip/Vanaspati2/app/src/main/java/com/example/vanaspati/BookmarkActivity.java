package com.example.vanaspati;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BookmarkActivity extends AppCompatActivity {

    private RecyclerView bookmarkRecyclerView;
    private TextView cartBadge; // Class member, not local
    private PlantAdapter plantAdapter;
    private TextView emptyMessage;
    private List<Plant> bookmarks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmark);

        bookmarkRecyclerView = findViewById(R.id.bookmark_recycler_view);
        emptyMessage = findViewById(R.id.empty_message);
        bookmarkRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        bookmarks = BookmarkManager.getBookmarks(this);
        plantAdapter = new PlantAdapter(this, bookmarks, true);
        bookmarkRecyclerView.setAdapter(plantAdapter);

        plantAdapter.setOnBookmarkRemovedListener(() -> checkIfEmpty());

        ImageView backIcon = findViewById(R.id.back_icon);
        if (backIcon != null) {
            backIcon.setOnClickListener(v -> finish());
        }

        // Using the class-level cartBadge variable
        cartBadge = findViewById(R.id.cart_badge);

        // Check cart items count and update badge visibility
        int itemCount = CartManager.getCartItems(this).size();
        if (itemCount > 0) {
            cartBadge.setVisibility(View.VISIBLE);
            cartBadge.setBackgroundResource(R.drawable.badge_background); // Set the custom badge background
            cartBadge.setText(""); // Clear the text to not show any number
        } else {
            cartBadge.setVisibility(View.GONE); // Hide if no items in cart
        }

        checkIfEmpty();

        // ✅ Bottom Navigation Click Handling
        findViewById(R.id.nav_home).setOnClickListener(v -> {
            startActivity(new Intent(this, HomePageActivity.class));
            overridePendingTransition(0, 0);
        });

        findViewById(R.id.nav_bookmark).setOnClickListener(v -> {
            Toast.makeText(this, "You're already on Bookmarks", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.nav_cart).setOnClickListener(v -> {
            startActivity(new Intent(this, CartActivity.class));
            overridePendingTransition(0, 0);
        });

        findViewById(R.id.nav_settings).setOnClickListener(v -> {
            startActivity(new Intent(this, SettingsPageActivity.class));
            overridePendingTransition(0, 0);
        });
    }

    private void checkIfEmpty() {
        if (bookmarks == null || bookmarks.isEmpty()) {
            bookmarkRecyclerView.setVisibility(View.GONE);
            if (emptyMessage != null) emptyMessage.setVisibility(View.VISIBLE);
        } else {
            bookmarkRecyclerView.setVisibility(View.VISIBLE);
            if (emptyMessage != null) emptyMessage.setVisibility(View.GONE);
        }
    }
}
