package com.example.vanaspati;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;

import java.util.*;

public class ChatActivity extends AppCompatActivity {

    private RecyclerView chatRecyclerView;
    private EditText messageEditText;
    private Button sendButton;

    private FirebaseFirestore db;
    private String currentUserId;
    private String doctorId;
    private ChatAdapter chatAdapter;
    private List<Message> messageList;
    private ListenerRegistration chatListener;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        chatRecyclerView = findViewById(R.id.chatRecyclerView);
        messageEditText = findViewById(R.id.messageEditText);
        sendButton = findViewById(R.id.sendButton);

        currentUserId = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid()
                : null;

        doctorId = getIntent().getStringExtra("doctorId");

        if (currentUserId == null || doctorId == null) {
            Toast.makeText(this, "Chat setup failed. Missing user or doctor ID.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        db = FirebaseFirestore.getInstance();
        messageList = new ArrayList<>();
        chatAdapter = new ChatAdapter(messageList, currentUserId);

        chatRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        chatRecyclerView.setAdapter(chatAdapter);

        sendButton.setOnClickListener(view -> sendMessage());

        listenForMessages();
    }

    private void sendMessage() {
        String text = messageEditText.getText().toString().trim();
        if (text.isEmpty()) return;

        Message message = new Message(currentUserId, doctorId, text, System.currentTimeMillis());

        db.collection("chats")
                .add(message)
                .addOnSuccessListener(documentReference -> {
                    messageEditText.setText("");
                    Log.d("Chat", "Message sent successfully");
                })
                .addOnFailureListener(e -> {
                    Log.e("Chat", "Send failed", e);
                    Toast.makeText(this, "Failed to send message", Toast.LENGTH_SHORT).show();
                });
    }

    private void listenForMessages() {
        chatListener = db.collection("chats")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Log.e("Chat", "Listen failed", error);
                        return;
                    }
                    if (value == null) return;

                    messageList.clear();
                    for (DocumentSnapshot doc : value.getDocuments()) {
                        Message msg = doc.toObject(Message.class);
                        if (msg != null &&
                                ((msg.getSenderId().equals(currentUserId) && msg.getReceiverId().equals(doctorId)) ||
                                        (msg.getSenderId().equals(doctorId) && msg.getReceiverId().equals(currentUserId)))) {
                            messageList.add(msg);
                        }
                    }

                    chatAdapter.notifyDataSetChanged();
                    if (!messageList.isEmpty()) {
                        chatRecyclerView.scrollToPosition(messageList.size() - 1);
                    }
                });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (chatListener != null) {
            chatListener.remove();
        }
    }
}
