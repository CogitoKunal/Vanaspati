package com.example.vanaspati;

import android.content.SharedPreferences;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.*;

public class LoginActivity extends AppCompatActivity {

    private EditText emailInput, passwordInput;
    private Button loginButton, passwordlessLoginButton;
    private TextView forgotPassword, goToRegister;
    private ProgressBar progressBar;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();

        emailInput = findViewById(R.id.email_input);
        passwordInput = findViewById(R.id.password_input);
        loginButton = findViewById(R.id.login_button);
        passwordlessLoginButton = findViewById(R.id.passwordless_login_button);
        progressBar = findViewById(R.id.progressBar);
        forgotPassword = findViewById(R.id.forgot_password);
        goToRegister = findViewById(R.id.go_to_register);

        loginButton.setOnClickListener(view -> loginUser());

        passwordlessLoginButton.setOnClickListener(view -> {
            Toast.makeText(this, "Coming Soon!", Toast.LENGTH_SHORT).show();
            // You can implement passwordless login here if needed
        });


        goToRegister.setOnClickListener(view -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            finish();
        });

        forgotPassword.setOnClickListener(view -> {
            String email = emailInput.getText().toString().trim();
            if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(this, "Enter valid email to reset password", Toast.LENGTH_SHORT).show();
                return;
            }

            mAuth.sendPasswordResetEmail(email)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(this, "Reset link sent to your email", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, "Failed to send reset email", Toast.LENGTH_SHORT).show();
                        }
                    });
        });
    }

    private void loginUser() {
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter both email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    progressBar.setVisibility(View.GONE);

                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null && user.isEmailVerified()) {
                            // ✅ Now check if name exists in Firestore, if not, save it
                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                            String uid = user.getUid();

                            db.collection("users").document(uid).get()
                                    .addOnSuccessListener(document -> {
                                        if (!document.exists() || !document.contains("name")) {
                                            // Get name from SharedPreferences
                                            SharedPreferences prefs = getSharedPreferences("VanaspatiPrefs", MODE_PRIVATE);
                                            String name = prefs.getString("pending_name", null);

                                            if (name != null) {
                                                // Save to Firestore
                                                Map<String, Object> userData = new HashMap<>();
                                                userData.put("name", name);
                                                userData.put("email", user.getEmail());

                                                db.collection("users").document(uid)
                                                        .set(userData)
                                                        .addOnSuccessListener(unused -> {
                                                            // Clear name from SharedPreferences
                                                            prefs.edit().remove("pending_name").apply();
                                                        });
                                            }
                                        }

                                        Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                                        finish();
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(this, "Login successful, but failed to check user data", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                                        finish();
                                    });

                        } else {
                            if (user != null) {
                                user.sendEmailVerification();
                            }
                            mAuth.signOut();
                            Toast.makeText(this, "Please verify your email before login. Verification link sent again.", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        String error = task.getException() != null ? task.getException().getMessage() : "Login failed.";
                        Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
                    }
                });
    }

}
