package com.example.vanaspati;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.FirebaseApp;  // Add FirebaseApp import
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.List;

public class DoctorListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DoctorAdapter doctorAdapter;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_list);

        // Initialize Firebase
        if (FirebaseApp.getApps(this).isEmpty()) {  // Checks if Firebase is already initialized
            FirebaseApp.initializeApp(this);  // Initialize Firebase
        }

        recyclerView = findViewById(R.id.doctorRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Load doctors from JSON
        List<Doctor> doctorList = loadDoctorsFromJson();

        if (doctorList != null && !doctorList.isEmpty()) {
            doctorAdapter = new DoctorAdapter(doctorList, this, new DoctorAdapter.OnDoctorActionListener() {
                @Override
                public void onChatRequested(Doctor doctor) {
                    sendRequestToDoctor(doctor.getId(), "chat");
                }

                @Override

                public void onVideoCallRequested(Doctor doctor) {
                    sendRequestToDoctor(doctor.getId(), "video");

                    // Start the VideoCallActivity
                    Intent intent = new Intent(DoctorListActivity.this, VideoCallActivity.class);
                    intent.putExtra("channelName", doctor.getId()); // or any unique ID for the room
                    startActivity(intent);

                }

            });
            recyclerView.setAdapter(doctorAdapter);
        } else {
            Toast.makeText(this, "Failed to load doctor data", Toast.LENGTH_SHORT).show();
        }
    }

    private List<Doctor> loadDoctorsFromJson() {
        AssetManager assetManager = getAssets();
        try {
            InputStream is = assetManager.open("doctors.json");
            InputStreamReader reader = new InputStreamReader(is);
            Type listType = new TypeToken<List<Doctor>>() {}.getType();
            return new Gson().fromJson(reader, listType);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void sendRequestToDoctor(String doctorId, String type) {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        Request request = new Request(userId, doctorId, type);

        // Firebase database reference
        FirebaseDatabase.getInstance().getReference("requests")
                .push()
                .setValue(request)
                .addOnSuccessListener(aVoid ->
                        Toast.makeText(this, type + " request sent", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to send request", Toast.LENGTH_SHORT).show());
    }
}
